package ibmmobileappbuilder.util.image;

public interface ImageLoader {

    void load(ImageLoaderRequest request);
}
